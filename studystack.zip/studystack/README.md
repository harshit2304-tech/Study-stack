# StudyStack

A SaaS productivity hub for students and coders: task board, markdown notes,
code snippet vault, and a Pomodoro focus timer — plus a marketing site,
auth, and a plan/billing stub, all in one Next.js app.

## Stack

- **Next.js 14** (App Router, server components, server actions)
- **TypeScript + Tailwind CSS**
- **Prisma + SQLite** (swap `DATABASE_URL` for Postgres in production)
- **Auth**: email + password, scrypt hashing, DB-backed session cookies
- **Markdown**: `marked` + `sanitize-html` (server-side, XSS-safe)
- **Highlighting**: `highlight.js` server-side

## Run locally

```bash
npm install
cp .env.example .env
npx prisma db push   # creates prisma/dev.db
npm run dev          # http://localhost:3000
```

## Production

```bash
npm run build        # prisma generate + db push + next build
npm start
```

Set `DATABASE_URL` (e.g. Postgres on Neon/Supabase/Railway) and deploy to
Vercel, Railway, Fly.io or a plain Node host.

## Billing

The Pro plan is a flag on the user record (`lib/actions/billing.ts`). Wire it
to Stripe Checkout when `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` are set.

## App map

| Route                  | Purpose                                |
| ---------------------- | -------------------------------------- |
| `/`                    | Marketing landing page                 |
| `/pricing`             | Pricing page                           |
| `/signup`, `/login`    | Auth                                   |
| `/dashboard`           | Overview stats and upcoming tasks      |
| `/dashboard/tasks`     | Kanban task board                      |
| `/dashboard/notes`     | Markdown notes with live preview       |
| `/dashboard/snippets`  | Code snippets with syntax highlighting |
| `/dashboard/focus`     | Pomodoro timer + session log           |
| `/dashboard/settings`  | Profile + plan management              |
