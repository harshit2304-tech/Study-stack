import { logout } from "@/lib/actions/auth";

export function LogoutButton() {
  return (
    <form action={logout}>
      <button
        type="submit"
        className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-left text-sm text-slate-600 hover:border-slate-400 hover:text-slate-900"
      >
        Log out
      </button>
    </form>
  );
}
