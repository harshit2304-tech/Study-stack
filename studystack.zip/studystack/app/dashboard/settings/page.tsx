import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { formatDate } from "@/lib/format";
import { setPlan } from "@/lib/actions/billing";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const user = await requireUser();
  const [taskCount, noteCount, snippetCount] = await Promise.all([
    db.task.count({ where: { userId: user.id } }),
    db.note.count({ where: { userId: user.id } }),
    db.snippet.count({ where: { userId: user.id } }),
  ]);

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-bold">Settings</h1>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="font-semibold">Profile</h2>
        <dl className="mt-4 space-y-3 text-sm">
          <div className="flex justify-between">
            <dt className="text-slate-500">Name</dt>
            <dd className="font-medium">{user.name}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Email</dt>
            <dd className="font-medium">{user.email}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Member since</dt>
            <dd className="font-medium">{formatDate(user.createdAt)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Workspace</dt>
            <dd className="font-medium">
              {taskCount} tasks · {noteCount} notes · {snippetCount} snippets
            </dd>
          </div>
        </dl>
      </section>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="font-semibold">Plan</h2>
        <div className="mt-4 flex items-center justify-between rounded-xl bg-slate-50 p-4">
          <div>
            <div className="text-sm font-semibold">
              {user.plan === "pro" ? "Pro plan" : "Free plan"}
            </div>
            <div className="mt-0.5 text-xs text-slate-500">
              {user.plan === "pro"
                ? "Unlimited snippets and all current features."
                : "25 snippet limit. Upgrade for unlimited storage."}
            </div>
          </div>
          <form
            action={async () => {
              "use server";
              await setPlan(user.plan === "pro" ? "free" : "pro");
            }}
          >
            <button
              type="submit"
              className={`rounded-lg px-4 py-2 text-sm font-semibold ${
                user.plan === "pro"
                  ? "border border-slate-300 text-slate-600 hover:border-slate-400"
                  : "bg-brand-600 text-white hover:bg-brand-700"
              }`}
            >
              {user.plan === "pro" ? "Downgrade" : "Upgrade to Pro"}
            </button>
          </form>
        </div>
        <p className="mt-3 text-xs text-slate-500">
          Billing is stubbed in this build — the plan flag flips instantly.
          Connect Stripe Checkout via the STRIPE_* env vars to charge real
          money.
        </p>
      </section>
    </div>
  );
}
