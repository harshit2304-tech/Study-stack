"use client";

import { useRef, useState } from "react";
import { createSnippet } from "@/lib/actions/snippets";

const LANGUAGES = [
  "plaintext", "javascript", "typescript", "python", "java", "c", "cpp",
  "csharp", "go", "rust", "sql", "bash", "html", "css", "json", "yaml",
  "php", "ruby", "swift", "kotlin",
];

export function NewSnippetForm() {
  const ref = useRef<HTMLFormElement>(null);
  const [open, setOpen] = useState(false);

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="rounded-xl bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
      >
        + New snippet
      </button>
    );
  }

  return (
    <form
      ref={ref}
      action={async (fd) => {
        await createSnippet(fd);
        ref.current?.reset();
        setOpen(false);
      }}
      className="space-y-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm"
    >
      <div className="flex flex-col gap-3 sm:flex-row">
        <input
          name="title"
          required
          maxLength={200}
          placeholder="Snippet title — e.g. Debounce hook"
          className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200"
        />
        <select
          name="language"
          defaultValue="typescript"
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200"
        >
          {LANGUAGES.map((l) => (
            <option key={l} value={l}>
              {l}
            </option>
          ))}
        </select>
      </div>
      <textarea
        name="code"
        required
        rows={6}
        placeholder="Paste your code…"
        className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200"
      />
      <input
        name="notes"
        maxLength={2000}
        placeholder="Optional note — when to use this"
        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200"
      />
      <div className="flex gap-2">
        <button
          type="submit"
          className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          Save snippet
        </button>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-600 hover:border-slate-400"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
