import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { highlightCode } from "@/lib/highlight";
import { NewSnippetForm } from "./NewSnippetForm";
import { SnippetActions } from "./SnippetActions";

export const metadata: Metadata = { title: "Snippets" };

export default async function SnippetsPage() {
  const user = await requireUser();
  const snippets = await db.snippet.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
  });
  const overLimit = user.plan !== "pro" && snippets.length >= 25;

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-2xl font-bold">Snippet vault</h1>
      <p className="mt-1 text-sm text-slate-600">
        Reusable code, saved once, copied forever.
      </p>

      <div className="mt-6">
        {overLimit ? (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
            Free plan holds 25 snippets. Upgrade to Pro in Settings for
            unlimited storage.
          </div>
        ) : (
          <NewSnippetForm />
        )}
      </div>

      <div className="mt-6 space-y-4">
        {snippets.length === 0 && (
          <p className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-400">
            No snippets yet — save your first one above.
          </p>
        )}
        {snippets.map((s) => (
          <div
            key={s.id}
            className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
          >
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2.5">
              <div className="flex min-w-0 items-center gap-3">
                <span className="truncate text-sm font-semibold">{s.title}</span>
                <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-mono text-slate-600">
                  {s.language}
                </span>
              </div>
              <SnippetActions snippetId={s.id} code={s.code} />
            </div>
            <pre className="overflow-x-auto bg-slate-50 p-4 text-[13px] leading-5">
              <code
                className="hljs"
                dangerouslySetInnerHTML={{
                  __html: highlightCode(s.code, s.language),
                }}
              />
            </pre>
            {s.notes && (
              <p className="border-t border-slate-100 px-4 py-2 text-xs text-slate-500">
                {s.notes}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
