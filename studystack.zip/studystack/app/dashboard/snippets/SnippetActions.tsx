"use client";

import { useState, useTransition } from "react";
import { deleteSnippet } from "@/lib/actions/snippets";

export function SnippetActions({
  snippetId,
  code,
}: {
  snippetId: string;
  code: string;
}) {
  const [copied, setCopied] = useState(false);
  const [pending, start] = useTransition();

  async function copy() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // clipboard unavailable (non-secure context) — ignore
    }
  }

  return (
    <div className="flex shrink-0 items-center gap-2">
      <button
        onClick={copy}
        className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-600 hover:border-brand-300 hover:text-brand-700"
      >
        {copied ? "Copied!" : "Copy"}
      </button>
      <button
        onClick={() => start(() => deleteSnippet(snippetId))}
        disabled={pending}
        className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs text-slate-500 hover:border-rose-300 hover:text-rose-600 disabled:opacity-50"
      >
        Delete
      </button>
    </div>
  );
}
