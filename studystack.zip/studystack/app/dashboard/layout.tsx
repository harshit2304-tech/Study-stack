import { requireUser } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { SideNav } from "@/components/SideNav";
import { LogoutButton } from "@/components/LogoutButton";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await requireUser();
  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="hidden w-60 shrink-0 flex-col border-r border-slate-200 bg-white sm:flex">
        <div className="flex h-16 items-center border-b border-slate-100 px-5">
          <Logo href="/dashboard" />
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <SideNav />
        </div>
        <div className="border-t border-slate-100 p-4">
          <div className="mb-2 truncate text-sm font-medium">{user.name}</div>
          <div className="mb-3 flex items-center gap-2">
            <span
              className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                user.plan === "pro"
                  ? "bg-brand-100 text-brand-700"
                  : "bg-slate-100 text-slate-600"
              }`}
            >
              {user.plan === "pro" ? "Pro" : "Free"}
            </span>
          </div>
          <LogoutButton />
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobile top bar */}
        <div className="flex h-14 items-center justify-between border-b border-slate-200 bg-white px-4 sm:hidden">
          <Logo href="/dashboard" />
          <LogoutButton />
        </div>
        <div className="border-b border-slate-200 bg-white px-4 py-2 sm:hidden">
          <SideNav horizontal />
        </div>
        <main className="flex-1 p-4 sm:p-8">{children}</main>
      </div>
    </div>
  );
}
