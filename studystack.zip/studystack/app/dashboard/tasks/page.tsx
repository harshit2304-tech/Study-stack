import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { TaskBoard } from "./TaskBoard";
import { NewTaskForm } from "./NewTaskForm";

export const metadata: Metadata = { title: "Tasks" };

export default async function TasksPage() {
  const user = await requireUser();
  const tasks = await db.task.findMany({
    where: { userId: user.id },
    orderBy: [{ status: "asc" }, { dueDate: "asc" }, { createdAt: "desc" }],
  });

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Tasks</h1>
          <p className="mt-1 text-sm text-slate-600">
            Assignments, projects, sprints — all in one board.
          </p>
        </div>
      </div>
      <div className="mt-6">
        <NewTaskForm />
      </div>
      <div className="mt-6">
        <TaskBoard tasks={tasks} />
      </div>
    </div>
  );
}
