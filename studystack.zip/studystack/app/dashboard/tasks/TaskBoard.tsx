"use client";

import { useTransition } from "react";
import type { Task } from "@prisma/client";
import { deleteTask, setTaskStatus } from "@/lib/actions/tasks";
import { formatDate, isOverdue } from "@/lib/format";

const COLUMNS: { key: string; label: string; hint: string }[] = [
  { key: "todo", label: "To do", hint: "Up next" },
  { key: "doing", label: "Doing", hint: "In progress" },
  { key: "done", label: "Done", hint: "Shipped" },
];

const PRIORITY_STYLE: Record<string, string> = {
  high: "bg-rose-100 text-rose-700",
  medium: "bg-amber-100 text-amber-700",
  low: "bg-slate-100 text-slate-600",
};

function TaskCard({ task }: { task: Task }) {
  const [pending, start] = useTransition();
  return (
    <div
      className={`rounded-xl border border-slate-200 bg-white p-3 shadow-sm ${
        pending ? "opacity-50" : ""
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div
            className={`text-sm font-medium ${
              task.status === "done" ? "text-slate-400 line-through" : ""
            }`}
          >
            {task.title}
          </div>
          {task.description && (
            <div className="mt-0.5 line-clamp-2 text-xs text-slate-500">
              {task.description}
            </div>
          )}
        </div>
        <button
          onClick={() => start(() => deleteTask(task.id))}
          className="shrink-0 rounded px-1.5 text-slate-400 hover:bg-slate-100 hover:text-rose-600"
          title="Delete task"
        >
          ×
        </button>
      </div>
      <div className="mt-2 flex items-center gap-2 text-xs">
        <span
          className={`rounded-full px-2 py-0.5 font-medium ${PRIORITY_STYLE[task.priority] ?? PRIORITY_STYLE.medium}`}
        >
          {task.priority}
        </span>
        {task.dueDate && (
          <span
            className={
              isOverdue(task.dueDate) && task.status !== "done"
                ? "font-medium text-rose-600"
                : "text-slate-500"
            }
          >
            {isOverdue(task.dueDate) && task.status !== "done" ? "Overdue · " : ""}
            {formatDate(task.dueDate)}
          </span>
        )}
      </div>
      <div className="mt-3 flex gap-1">
        {COLUMNS.filter((c) => c.key !== task.status).map((c) => (
          <button
            key={c.key}
            onClick={() => start(() => setTaskStatus(task.id, c.key))}
            className="rounded-md border border-slate-200 px-2 py-1 text-xs text-slate-600 hover:border-brand-300 hover:text-brand-700"
          >
            → {c.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function TaskBoard({ tasks }: { tasks: Task[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-3">
      {COLUMNS.map((col) => {
        const items = tasks.filter((t) => t.status === col.key);
        return (
          <div key={col.key} className="rounded-2xl bg-slate-100/70 p-3">
            <div className="mb-3 flex items-baseline justify-between px-1">
              <h2 className="text-sm font-semibold">
                {col.label}
                <span className="ml-2 text-xs font-normal text-slate-500">
                  {items.length}
                </span>
              </h2>
              <span className="text-xs text-slate-400">{col.hint}</span>
            </div>
            <div className="space-y-3">
              {items.map((t) => (
                <TaskCard key={t.id} task={t} />
              ))}
              {items.length === 0 && (
                <div className="rounded-xl border border-dashed border-slate-300 p-4 text-center text-xs text-slate-400">
                  Nothing here
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
