import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { FocusTimer } from "./FocusTimer";

export const metadata: Metadata = { title: "Focus" };

export default async function FocusPage() {
  const user = await requireUser();
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const startOfWeek = new Date(startOfToday);
  startOfWeek.setDate(startOfWeek.getDate() - 6);

  const [todayAgg, weekAgg, recent] = await Promise.all([
    db.focusSession.aggregate({
      _sum: { minutes: true },
      _count: true,
      where: {
        userId: user.id,
        kind: "focus",
        completedAt: { gte: startOfToday },
      },
    }),
    db.focusSession.aggregate({
      _sum: { minutes: true },
      where: {
        userId: user.id,
        kind: "focus",
        completedAt: { gte: startOfWeek },
      },
    }),
    db.focusSession.findMany({
      where: { userId: user.id },
      orderBy: { completedAt: "desc" },
      take: 10,
    }),
  ]);

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-2xl font-bold">Focus timer</h1>
      <p className="mt-1 text-sm text-slate-600">
        Pomodoro-style sessions. Completed focus blocks are logged automatically.
      </p>

      <div className="mt-6 grid gap-6 sm:grid-cols-[1fr_320px]">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
          <FocusTimer />
        </div>
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Today
            </div>
            <div className="mt-1 text-2xl font-bold">
              {todayAgg._sum.minutes ?? 0}
              <span className="ml-1 text-sm font-normal text-slate-500">min</span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {todayAgg._count} session{todayAgg._count === 1 ? "" : "s"}
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Last 7 days
            </div>
            <div className="mt-1 text-2xl font-bold">
              {weekAgg._sum.minutes ?? 0}
              <span className="ml-1 text-sm font-normal text-slate-500">min</span>
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-2 text-xs font-medium uppercase tracking-wide text-slate-500">
              Recent sessions
            </div>
            {recent.length === 0 ? (
              <p className="text-xs text-slate-400">
                No sessions yet — start the timer.
              </p>
            ) : (
              <ul className="space-y-2 text-xs">
                {recent.map((s) => (
                  <li key={s.id} className="flex justify-between text-slate-600">
                    <span>
                      {s.minutes}m {s.kind}
                    </span>
                    <span className="text-slate-400">
                      {new Date(s.completedAt).toLocaleDateString("en", {
                        month: "short",
                        day: "numeric",
                      })}{" "}
                      {new Date(s.completedAt).toLocaleTimeString("en", {
                        hour: "numeric",
                        minute: "2-digit",
                      })}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
