"use client";

import { useEffect, useRef, useState } from "react";
import { logFocusSession } from "@/lib/actions/focus";

const PHASES = {
  focus: { label: "Focus", minutes: 25 },
  break: { label: "Break", minutes: 5 },
} as const;

type Phase = keyof typeof PHASES;

function fmt(totalSeconds: number) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function FocusTimer() {
  const [phase, setPhase] = useState<Phase>("focus");
  const [secondsLeft, setSecondsLeft] = useState(PHASES.focus.minutes * 60);
  const [running, setRunning] = useState(false);
  const [rounds, setRounds] = useState(0);
  const interval = useRef<ReturnType<typeof setInterval> | null>(null);

  const total = PHASES[phase].minutes * 60;
  const progress = 1 - secondsLeft / total;

  useEffect(() => {
    if (!running) return;
    interval.current = setInterval(() => {
      setSecondsLeft((s) => s - 1);
    }, 1000);
    return () => {
      if (interval.current) clearInterval(interval.current);
    };
  }, [running]);

  useEffect(() => {
    if (secondsLeft > 0) return;
    // Phase finished.
    if (interval.current) clearInterval(interval.current);
    setRunning(false);
    const finished = PHASES[phase];
    logFocusSession(finished.minutes, phase);
    if (phase === "focus") {
      setRounds((r) => r + 1);
      switchPhase("break");
    } else {
      switchPhase("focus");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft]);

  function switchPhase(p: Phase) {
    setPhase(p);
    setSecondsLeft(PHASES[p].minutes * 60);
    setRunning(false);
  }

  function reset() {
    setSecondsLeft(PHASES[phase].minutes * 60);
    setRunning(false);
  }

  const R = 88;
  const CIRC = 2 * Math.PI * R;

  return (
    <div className="flex flex-col items-center">
      <div className="flex gap-2">
        {(Object.keys(PHASES) as Phase[]).map((p) => (
          <button
            key={p}
            onClick={() => switchPhase(p)}
            className={`rounded-lg px-4 py-1.5 text-sm font-medium capitalize ${
              phase === p
                ? "bg-brand-600 text-white"
                : "border border-slate-300 text-slate-600 hover:border-slate-400"
            }`}
          >
            {PHASES[p].label} · {PHASES[p].minutes}m
          </button>
        ))}
      </div>

      <div className="relative mt-8">
        <svg width="220" height="220" viewBox="0 0 220 220">
          <circle
            cx="110" cy="110" r={R}
            fill="none" stroke="#e2e8f0" strokeWidth="12"
          />
          <circle
            cx="110" cy="110" r={R}
            fill="none"
            stroke={phase === "focus" ? "#1d64f1" : "#10b981"}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC * (1 - progress)}
            transform="rotate(-90 110 110)"
            className="transition-all duration-1000"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="font-mono text-5xl font-bold tabular-nums">
            {fmt(Math.max(0, secondsLeft))}
          </div>
          <div className="mt-1 text-xs uppercase tracking-widest text-slate-500">
            {PHASES[phase].label}
          </div>
        </div>
      </div>

      <div className="mt-8 flex gap-3">
        <button
          onClick={() => setRunning((r) => !r)}
          className={`rounded-xl px-8 py-3 text-sm font-semibold text-white ${
            running
              ? "bg-slate-700 hover:bg-slate-800"
              : "bg-brand-600 hover:bg-brand-700"
          }`}
        >
          {running ? "Pause" : secondsLeft < total ? "Resume" : "Start"}
        </button>
        <button
          onClick={reset}
          className="rounded-xl border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-600 hover:border-slate-400"
        >
          Reset
        </button>
      </div>

      <p className="mt-6 text-xs text-slate-500">
        {rounds} focus round{rounds === 1 ? "" : "s"} completed this visit
      </p>
    </div>
  );
}
