import Link from "next/link";
import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { formatDate, isOverdue } from "@/lib/format";

export const metadata: Metadata = { title: "Overview" };

export default async function DashboardPage() {
  const user = await requireUser();
  const now = new Date();
  const startOfToday = new Date(now);
  startOfToday.setHours(0, 0, 0, 0);
  const startOfWeek = new Date(startOfToday);
  startOfWeek.setDate(startOfWeek.getDate() - 6);

  const [openTasks, doneThisWeek, noteCount, snippetCount, focusWeek, upcoming] =
    await Promise.all([
      db.task.count({ where: { userId: user.id, status: { not: "done" } } }),
      db.task.count({
        where: { userId: user.id, status: "done", updatedAt: { gte: startOfWeek } },
      }),
      db.note.count({ where: { userId: user.id } }),
      db.snippet.count({ where: { userId: user.id } }),
      db.focusSession.aggregate({
        _sum: { minutes: true },
        where: { userId: user.id, kind: "focus", completedAt: { gte: startOfWeek } },
      }),
      db.task.findMany({
        where: { userId: user.id, status: { not: "done" } },
        orderBy: [{ dueDate: "asc" }, { createdAt: "asc" }],
        take: 6,
      }),
    ]);

  const focusMinutes = focusWeek._sum.minutes ?? 0;

  const stats = [
    { label: "Open tasks", value: openTasks, href: "/dashboard/tasks" },
    { label: "Done this week", value: doneThisWeek, href: "/dashboard/tasks" },
    { label: "Notes", value: noteCount, href: "/dashboard/notes" },
    { label: "Snippets", value: snippetCount, href: "/dashboard/snippets" },
    {
      label: "Focus minutes (7d)",
      value: focusMinutes,
      href: "/dashboard/focus",
    },
  ];

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-2xl font-bold">Hey, {user.name.split(" ")[0]}</h1>
      <p className="mt-1 text-sm text-slate-600">
        Here&apos;s your workspace at a glance.
      </p>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <Link
            key={s.label}
            href={s.href}
            className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm hover:border-brand-300"
          >
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="mt-1 text-xs text-slate-500">{s.label}</div>
          </Link>
        ))}
      </div>

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Up next</h2>
          <Link
            href="/dashboard/tasks"
            className="text-sm font-medium text-brand-600 hover:underline"
          >
            All tasks →
          </Link>
        </div>
        {upcoming.length === 0 ? (
          <p className="mt-4 text-sm text-slate-500">
            No open tasks.{" "}
            <Link href="/dashboard/tasks" className="text-brand-600 hover:underline">
              Add your first task
            </Link>
            .
          </p>
        ) : (
          <ul className="mt-4 divide-y divide-slate-100">
            {upcoming.map((t) => (
              <li key={t.id} className="flex items-center justify-between py-3">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{t.title}</div>
                  {t.description && (
                    <div className="truncate text-xs text-slate-500">
                      {t.description}
                    </div>
                  )}
                </div>
                <div className="ml-4 flex shrink-0 items-center gap-3 text-xs">
                  <span
                    className={`rounded-full px-2 py-0.5 font-medium ${
                      t.priority === "high"
                        ? "bg-rose-100 text-rose-700"
                        : t.priority === "low"
                          ? "bg-slate-100 text-slate-600"
                          : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    {t.priority}
                  </span>
                  {t.dueDate && (
                    <span
                      className={
                        isOverdue(t.dueDate)
                          ? "font-medium text-rose-600"
                          : "text-slate-500"
                      }
                    >
                      {isOverdue(t.dueDate) ? "Overdue · " : ""}
                      {formatDate(t.dueDate)}
                    </span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
