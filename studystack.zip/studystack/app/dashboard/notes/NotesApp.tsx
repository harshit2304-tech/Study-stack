"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import type { Note } from "@prisma/client";
import { createNote, deleteNote, updateNote } from "@/lib/actions/notes";
import { previewMarkdown } from "@/lib/actions/preview";
import { formatDate } from "@/lib/format";

export function NotesApp({ initialNotes }: { initialNotes: Note[] }) {
  const [notes, setNotes] = useState<Note[]>(initialNotes);
  const [selectedId, setSelectedId] = useState<string | null>(
    initialNotes[0]?.id ?? null,
  );
  const [title, setTitle] = useState(initialNotes[0]?.title ?? "");
  const [content, setContent] = useState(initialNotes[0]?.content ?? "");
  const [previewHtml, setPreviewHtml] = useState("");
  const [mode, setMode] = useState<"write" | "preview">("write");
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const [pending, start] = useTransition();
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Keep local list in sync when server props refresh (create/delete).
  useEffect(() => {
    setNotes(initialNotes);
  }, [initialNotes]);

  const selected = notes.find((n) => n.id === selectedId) ?? null;

  function select(note: Note) {
    setSelectedId(note.id);
    setTitle(note.title);
    setContent(note.content);
    setMode("write");
  }

  // Debounced autosave.
  useEffect(() => {
    if (!selectedId || !selected) return;
    if (title === selected.title && content === selected.content) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      start(async () => {
        await updateNote(selectedId, title, content);
        setSavedAt(new Date());
      });
    }, 700);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title, content]);

  // Debounced preview render (sanitized on the server).
  useEffect(() => {
    if (mode !== "preview") return;
    const t = setTimeout(() => {
      previewMarkdown(content).then(setPreviewHtml);
    }, 200);
    return () => clearTimeout(t);
  }, [content, mode]);

  async function addNote() {
    const fd = new FormData();
    fd.set("title", "Untitled note");
    const id = await createNote(fd);
    if (id) {
      setSelectedId(id);
      setTitle("Untitled note");
      setContent("");
      setMode("write");
    }
  }

  function removeNote(id: string) {
    start(async () => {
      await deleteNote(id);
      const remaining = notes.filter((n) => n.id !== id);
      if (selectedId === id) {
        const next = remaining[0];
        setSelectedId(next?.id ?? null);
        setTitle(next?.title ?? "");
        setContent(next?.content ?? "");
      }
    });
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-6xl gap-4">
      {/* Sidebar list */}
      <div className="flex w-64 shrink-0 flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-100 p-3">
          <h1 className="text-sm font-semibold">Notes</h1>
          <button
            onClick={addNote}
            className="rounded-lg bg-brand-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-brand-700"
          >
            + New
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {notes.length === 0 && (
            <p className="p-3 text-xs text-slate-400">
              No notes yet — create your first one.
            </p>
          )}
          {notes.map((n) => (
            <button
              key={n.id}
              onClick={() => select(n)}
              className={`block w-full rounded-lg px-3 py-2 text-left ${
                n.id === selectedId ? "bg-brand-50" : "hover:bg-slate-50"
              }`}
            >
              <div className="truncate text-sm font-medium">{n.title}</div>
              <div className="mt-0.5 text-xs text-slate-400">
                {formatDate(n.updatedAt)}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Editor */}
      <div className="flex min-w-0 flex-1 flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
        {selected ? (
          <>
            <div className="flex items-center gap-3 border-b border-slate-100 p-3">
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={200}
                placeholder="Note title"
                className="min-w-0 flex-1 rounded-lg px-2 py-1 text-base font-semibold focus:bg-slate-50 focus:outline-none"
              />
              <div className="flex rounded-lg border border-slate-200 p-0.5 text-xs">
                {(["write", "preview"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setMode(m)}
                    className={`rounded-md px-3 py-1 font-medium capitalize ${
                      mode === m ? "bg-brand-600 text-white" : "text-slate-600"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">
                {pending ? "Saving…" : savedAt ? "Saved" : ""}
              </span>
              <button
                onClick={() => removeNote(selected.id)}
                className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs text-slate-500 hover:border-rose-300 hover:text-rose-600"
              >
                Delete
              </button>
            </div>
            {mode === "write" ? (
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write in markdown… # Heading, **bold**, `code`, - lists"
                className="min-h-0 flex-1 resize-none p-4 font-mono text-sm leading-6 focus:outline-none"
              />
            ) : (
              <div
                className="markdown-body min-h-0 flex-1 overflow-y-auto p-4"
                dangerouslySetInnerHTML={{ __html: previewHtml }}
              />
            )}
          </>
        ) : (
          <div className="flex flex-1 items-center justify-center p-8 text-center">
            <div>
              <p className="text-sm text-slate-500">
                Select a note or create a new one.
              </p>
              <button
                onClick={addNote}
                className="mt-4 rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
              >
                + New note
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
