import Link from "next/link";
import { PublicNav } from "@/components/PublicNav";

const FEATURES = [
  {
    title: "Task board",
    desc: "Plan assignments, projects and sprints on a simple kanban with priorities and due dates.",
    icon: "✓",
  },
  {
    title: "Markdown notes",
    desc: "Lecture notes, meeting minutes, cheatsheets — write in markdown, preview instantly.",
    icon: "✎",
  },
  {
    title: "Snippet vault",
    desc: "Save reusable code snippets with syntax highlighting and one-click copy.",
    icon: "</>",
  },
  {
    title: "Focus timer",
    desc: "Built-in Pomodoro timer that logs your deep-work sessions automatically.",
    icon: "◷",
  },
  {
    title: "Dashboard",
    desc: "See today's tasks, weekly focus time and your streak at a glance.",
    icon: "▦",
  },
  {
    title: "Private by default",
    desc: "Your tasks, notes and code live in your own workspace — never shared.",
    icon: "⚿",
  },
];

const STEPS = [
  { n: "1", title: "Create your workspace", desc: "Sign up in seconds — no credit card needed." },
  { n: "2", title: "Capture everything", desc: "Drop in tasks, notes and snippets as you work." },
  { n: "3", title: "Focus and ship", desc: "Run a focus session, check off tasks, repeat." },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <PublicNav />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-brand-50 via-white to-white" />
        <div className="mx-auto max-w-6xl px-4 pb-20 pt-20 text-center sm:pt-28">
          <span className="inline-block rounded-full border border-brand-200 bg-brand-50 px-3 py-1 text-xs font-medium text-brand-700">
            For students and coders
          </span>
          <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-extrabold tracking-tight text-slate-900 sm:text-6xl">
            Study smarter. <span className="text-brand-600">Ship faster.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            StudyStack puts your tasks, notes, code snippets and focus sessions in
            one clean workspace — so you spend less time organizing and more
            time doing.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4">
            <Link
              href="/signup"
              className="rounded-xl bg-brand-600 px-6 py-3 text-sm font-semibold text-white shadow-sm hover:bg-brand-700"
            >
              Start free
            </Link>
            <Link
              href="/pricing"
              className="rounded-xl border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-700 hover:border-slate-400"
            >
              See pricing
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="border-t border-slate-100 bg-slate-50 py-20">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-center text-3xl font-bold tracking-tight">
            Everything you need to get work done
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-center text-slate-600">
            Four focused tools, one tab. No bloat, no context switching.
          </p>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-100 font-mono text-sm font-bold text-brand-700">
                  {f.icon}
                </div>
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-center text-3xl font-bold tracking-tight">How it works</h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-3">
            {STEPS.map((s) => (
              <div key={s.n} className="text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-brand-600 text-lg font-bold text-white">
                  {s.n}
                </div>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-slate-100 bg-brand-600 py-16">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl font-bold text-white">
            Your next deadline is closer than you think.
          </h2>
          <p className="mt-3 text-brand-100">
            Set up your workspace in under a minute.
          </p>
          <Link
            href="/signup"
            className="mt-8 inline-block rounded-xl bg-white px-8 py-3 text-sm font-semibold text-brand-700 hover:bg-brand-50"
          >
            Create free account
          </Link>
        </div>
      </section>

      <footer className="border-t border-slate-200 py-8">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 text-sm text-slate-500">
          <span>© {new Date().getFullYear()} StudyStack</span>
          <div className="flex gap-6">
            <Link href="/pricing" className="hover:text-slate-900">Pricing</Link>
            <Link href="/login" className="hover:text-slate-900">Log in</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
