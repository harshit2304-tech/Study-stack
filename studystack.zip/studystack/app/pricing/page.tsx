import Link from "next/link";
import type { Metadata } from "next";
import { PublicNav } from "@/components/PublicNav";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Pricing" };

const PLANS = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    blurb: "Everything you need to get organized.",
    features: [
      "Unlimited tasks and notes",
      "Up to 25 saved snippets",
      "Focus timer + session log",
      "Dashboard overview",
    ],
    cta: "Start free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$6",
    period: "per month",
    blurb: "For power users who live in their workspace.",
    features: [
      "Everything in Free",
      "Unlimited snippets",
      "Priority tags and filters",
      "Focus analytics and streaks",
      "Early access to new tools",
    ],
    cta: "Go Pro",
    highlight: true,
  },
];

export default async function PricingPage() {
  const user = await getCurrentUser();
  return (
    <div className="min-h-screen bg-white">
      <PublicNav />
      <section className="mx-auto max-w-5xl px-4 py-20">
        <h1 className="text-center text-4xl font-extrabold tracking-tight">
          Simple, honest pricing
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-center text-slate-600">
          Start free. Upgrade when you need more room. Cancel anytime.
        </p>
        <div className="mt-14 grid gap-8 sm:grid-cols-2">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`rounded-2xl border p-8 shadow-sm ${
                plan.highlight
                  ? "border-brand-500 ring-2 ring-brand-200"
                  : "border-slate-200"
              }`}
            >
              <h2 className="text-lg font-semibold">{plan.name}</h2>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-4xl font-extrabold">{plan.price}</span>
                <span className="text-sm text-slate-500">{plan.period}</span>
              </div>
              <p className="mt-2 text-sm text-slate-600">{plan.blurb}</p>
              <ul className="mt-6 space-y-2 text-sm text-slate-700">
                {plan.features.map((f) => (
                  <li key={f} className="flex gap-2">
                    <span className="text-brand-600">✓</span>
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href={user ? "/dashboard/settings" : "/signup"}
                className={`mt-8 block rounded-xl px-4 py-3 text-center text-sm font-semibold ${
                  plan.highlight
                    ? "bg-brand-600 text-white hover:bg-brand-700"
                    : "border border-slate-300 text-slate-700 hover:border-slate-400"
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
        <p className="mt-10 text-center text-xs text-slate-500">
          Pro is a plan flag on your account in this build — wire it to Stripe
          Checkout with the STRIPE_* env vars when you go live.
        </p>
      </section>
    </div>
  );
}
