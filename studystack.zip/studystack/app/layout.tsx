import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "StudyStack — Study and ship faster",
    template: "%s · StudyStack",
  },
  description:
    "StudyStack is the productivity hub for students and coders: tasks, markdown notes, code snippets, and a focus timer in one clean workspace.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
