"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

// Placeholder billing: flips the plan flag stored on the user.
// Swap the internals for a Stripe Checkout session when STRIPE_* env
// vars are configured — see .env.
export async function setPlan(plan: string) {
  const user = await requireUser();
  const next = plan === "pro" ? "pro" : "free";
  await db.user.update({ where: { id: user.id }, data: { plan: next } });
  revalidatePath("/dashboard/settings");
  revalidatePath("/dashboard");
}
