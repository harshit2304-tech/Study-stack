"use server";

import { requireUser } from "@/lib/auth";
import { renderMarkdown } from "@/lib/markdown";

export async function previewMarkdown(content: string): Promise<string> {
  await requireUser();
  return renderMarkdown(content.slice(0, 100_000));
}
