"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

const STATUSES = ["todo", "doing", "done"] as const;
const PRIORITIES = ["low", "medium", "high"] as const;

export async function createTask(formData: FormData) {
  const user = await requireUser();
  const title = String(formData.get("title") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const priority = String(formData.get("priority") ?? "medium");
  const dueDateRaw = String(formData.get("dueDate") ?? "").trim();

  if (!title || title.length > 200) return;

  await db.task.create({
    data: {
      title,
      description,
      priority: (PRIORITIES as readonly string[]).includes(priority) ? priority : "medium",
      dueDate: dueDateRaw ? new Date(`${dueDateRaw}T00:00:00`) : null,
      userId: user.id,
    },
  });
  revalidatePath("/dashboard/tasks");
  revalidatePath("/dashboard");
}

export async function setTaskStatus(taskId: string, status: string) {
  const user = await requireUser();
  if (!(STATUSES as readonly string[]).includes(status)) return;
  await db.task.updateMany({
    where: { id: taskId, userId: user.id },
    data: { status },
  });
  revalidatePath("/dashboard/tasks");
  revalidatePath("/dashboard");
}

export async function deleteTask(taskId: string) {
  const user = await requireUser();
  await db.task.deleteMany({ where: { id: taskId, userId: user.id } });
  revalidatePath("/dashboard/tasks");
  revalidatePath("/dashboard");
}
