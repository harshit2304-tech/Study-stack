"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function createSnippet(formData: FormData) {
  const user = await requireUser();
  const title = String(formData.get("title") ?? "").trim();
  const language = String(formData.get("language") ?? "plaintext").trim() || "plaintext";
  const code = String(formData.get("code") ?? "");
  const notes = String(formData.get("notes") ?? "").trim();

  if (!title || !code.trim()) return;

  await db.snippet.create({
    data: {
      title: title.slice(0, 200),
      language: language.slice(0, 40),
      code: code.slice(0, 100_000),
      notes: notes.slice(0, 2000),
      userId: user.id,
    },
  });
  revalidatePath("/dashboard/snippets");
}

export async function deleteSnippet(snippetId: string) {
  const user = await requireUser();
  await db.snippet.deleteMany({ where: { id: snippetId, userId: user.id } });
  revalidatePath("/dashboard/snippets");
}
