"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function createNote(formData: FormData) {
  const user = await requireUser();
  const title = String(formData.get("title") ?? "").trim() || "Untitled note";
  const note = await db.note.create({
    data: { title: title.slice(0, 200), content: "", userId: user.id },
  });
  revalidatePath("/dashboard/notes");
  return note.id;
}

export async function updateNote(noteId: string, title: string, content: string) {
  const user = await requireUser();
  await db.note.updateMany({
    where: { id: noteId, userId: user.id },
    data: {
      title: (title.trim() || "Untitled note").slice(0, 200),
      content: content.slice(0, 100_000),
    },
  });
  revalidatePath("/dashboard/notes");
}

export async function deleteNote(noteId: string) {
  const user = await requireUser();
  await db.note.deleteMany({ where: { id: noteId, userId: user.id } });
  revalidatePath("/dashboard/notes");
}
