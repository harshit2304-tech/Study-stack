"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function logFocusSession(minutes: number, kind: string) {
  const user = await requireUser();
  const mins = Math.round(minutes);
  if (mins < 1 || mins > 480) return;
  await db.focusSession.create({
    data: {
      minutes: mins,
      kind: kind === "break" ? "break" : "focus",
      userId: user.id,
    },
  });
  revalidatePath("/dashboard/focus");
  revalidatePath("/dashboard");
}
