import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef6ff",
          100: "#d9ebff",
          200: "#bcddff",
          300: "#8ec8ff",
          400: "#59a9ff",
          500: "#3385fc",
          600: "#1d64f1",
          700: "#154ede",
          800: "#1841b4",
          900: "#193a8d",
        },
      },
    },
  },
  plugins: [],
};
export default config;
